import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from '../order/order';
import { Product } from '../order/product';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  

  private baseUrl = 'http://localhost:8080/orders/';  

 private baseUrlp = 'http://localhost:8080/products/';  

 private baseUrlu = 'http://localhost:8080/users/'; 

 private baseUrls = 'http://localhost:8080/signup/'; 

  constructor(private http:HttpClient) { }




  getOrderList(): Observable<Order[]> {  
    return this.http.get<Order[]>(`${this.baseUrl}`);  
  }  
  
  createOrder(order: object): Observable<object> {  
    return this.http.post(`${this.baseUrl}`, order);  
  }  
  
  deleteOrder(id: number): Observable<any> {  
    return this.http.delete(`${this.baseUrl}${id}`, { responseType: 'text' });  
  }  
  
  getOrder(id: number): Observable<Order> {  
    return this.http.get<Order>(`${this.baseUrl}${id}`);  
  }  
  
  updateOrder(id: number, value: any): Observable<Object> {  
    return this.http.put(`${this.baseUrl}${id}`, value);  
  }  
    
  getProductList(): Observable<Product[]> {  
    return this.http.get<Product[]>(`${this.baseUrlp}`);  
  }  
  getProductByName(name: string) {  
    return this.http.get(`${this.baseUrlp}${name}`);  
  }
  
  addUser(user: object): Observable<object> {  
    return this.http.post(`${this.baseUrls}`, user);  
  }  
  loginUser(user: object): Observable<object> {  
    console.log(user);
    return this.http.post(`${this.baseUrlu}`, user);  
  }  
}  