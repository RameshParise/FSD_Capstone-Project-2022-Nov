import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrderRoutingModule } from './order-routing.module';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HeaderComponent } from './header/header.component';
import { MaterialModule } from '../material/material.module';
import { NewOrderComponent } from './new-order/new-order.component';
import { UpdateOrderComponent } from './update-order/update-order.component';
import { OrderListComponent } from './order-list/order-list.component';
import { ProductListComponent } from './product-list/product-list.component';
import { SearchFilterPipe } from './search-filter.pipe';



@NgModule({
  declarations: [
    LoginComponent,
    SignupComponent,
    HeaderComponent,
    NewOrderComponent,
    UpdateOrderComponent,
    OrderListComponent,
    ProductListComponent,
    SearchFilterPipe

  ],
  imports: [
    CommonModule,
    OrderRoutingModule,
    MaterialModule
  ]
})
export class OrderModule { }
