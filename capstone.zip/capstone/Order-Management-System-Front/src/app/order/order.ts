import { Product } from "./product";

export class Order {
  orderId!: number;
  product!: string;
    price!: number;
    quantity!: number;
    phone!:string;
    email!: string;
    address!: string;
  constructor(){}
}
