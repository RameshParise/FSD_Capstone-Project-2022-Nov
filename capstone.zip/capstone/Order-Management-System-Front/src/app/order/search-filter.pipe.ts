import { Pipe, PipeTransform } from '@angular/core';
import { Order } from './order';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

  transform(orders:Order[], searchValue:string): Order[] {

    if (!orders || !searchValue) {
      return orders;
    }
    return orders.filter(Order =>
      Order.orderId.toLocaleString().includes(searchValue.toLocaleLowerCase())
    );
  }

}
