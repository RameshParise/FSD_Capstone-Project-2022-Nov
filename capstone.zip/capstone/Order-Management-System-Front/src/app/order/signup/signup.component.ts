import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { OrderService } from 'src/app/shared/order.service';
import { User } from '../user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  signupForm!: FormGroup;
  user:User=new User();
  constructor(private service:OrderService,private router:Router,public formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.signupForm= this.formBuilder.group({
      username: new FormControl('',[Validators.required]),
      email: new FormControl('',[Validators.required]),
      password: new FormControl('',[Validators.required])
      
    })
  }
  get getControl(){
    return this.signupForm.controls;
  }
  
  saveUser()
  {
    this.service.addUser(this.user).subscribe(data=>{
      console.log(data);
      this.goToLogin();
    })
  }

  goToLogin(){
    this.router.navigate(['/order/login']);
  }
  onSubmit(){
    this.saveUser();
}
}