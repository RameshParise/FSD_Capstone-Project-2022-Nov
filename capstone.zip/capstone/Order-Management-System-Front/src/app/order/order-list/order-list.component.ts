import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from 'src/app/shared/order.service';
import { Order } from '../order';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss']
})
export class OrderListComponent implements OnInit {

  orders!:Order[];

  searchValue!: string;

  constructor(private service:OrderService,private router:Router) { }
  ngOnInit(): void {
    this.getOrders();
  }

   getOrders(){
    this.service.getOrderList().subscribe(data =>{
      this.orders=data;
      console.log(this.orders);
    })
  }

  updateOrder(orderId: number){
    this.router.navigate(['order/update', orderId]);
  }

  deleteOrder(id: number){
    this.service.deleteOrder(id).subscribe(data =>{
      console.log(data);
      this.getOrders();
    })
  }
  
  }
