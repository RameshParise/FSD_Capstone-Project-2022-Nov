export class Product {
    productId!: number;
    name!: string;
    price!: number;
    description!: string;
    warranty!: string;
    constructor(){}
}

