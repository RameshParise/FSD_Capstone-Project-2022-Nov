import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { OrderService } from 'src/app/shared/order.service';
import { User } from '../user';

interface Alert {
	type: string;
	message: string;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  @ViewChild("form")
  form!: NgForm; 
  isAlert:any;
  noAlert:any;
  loginForm!: FormGroup;
  user:User=new User();
  
  
  constructor(private service:OrderService,private router:Router,public formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.loginForm= this.formBuilder.group({
      username: new FormControl('',[Validators.required]),
      password: new FormControl('',[Validators.required])
    })
  }
  get getControl(){
    return this.loginForm.controls;
  }
  
  loginUser()
  {
    this.service.loginUser(this.user).subscribe(data=>{
     this.isAlert=true;
    },
    error=>this.noAlert=true);
  }

  goToProductList(){
    this.router.navigate(['/order/product']);
  }
  onSubmit(){
    this.loginUser();
  }
  closes()
  {
    this.goToProductList();
  }
  closex()
  {
    this.user.username = ''; 
     this.user.password = '';
  }
  reset()
  {
    this.router.navigate([""]);
  }

}