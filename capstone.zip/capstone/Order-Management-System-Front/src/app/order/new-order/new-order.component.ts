import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from 'src/app/shared/order.service';
import { Order } from '../order';


@Component({
  selector: 'app-new-order',
  templateUrl: './new-order.component.html',
  styleUrls: ['./new-order.component.scss']
})
export class NewOrderComponent implements OnInit {

  order:Order=new Order();
  constructor(private service:OrderService,private router:Router) { }
  
  ngOnInit(): void {
  }
  
  saveOrder(){
    this.service.createOrder(this.order).subscribe(data =>{
      console.log(data);
      this.goToOrderList();
    }
    )
  }

  goToOrderList(){
    this.router.navigate(['order/list']);
  }

  onSubmit(){
    console.log(this.order);
    this.saveOrder();
  }
}
