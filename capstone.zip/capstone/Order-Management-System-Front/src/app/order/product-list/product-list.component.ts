import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderService } from 'src/app/shared/order.service';
import { Order } from '../order';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  title = ["FootBall", "Hockey Stick", "bat", "ball", "shuttlecock", "stumps","Badminton Racket", "volleyball"]

  order: Order = new Order();
  dataSource: any = [];
  orders: Order[] = [];
  name!: string;
  product: any;
  orderD: any;
  constructor(private service: OrderService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {


  }

  getProductByName(name: any) {
    this.service.getProductByName(name).subscribe(data => {
      this.product = data;
      console.log(this.product);
    })
  }
  footBall() {
    this.getProductByName(this.title[0]);
  }

  hockeyStick() {
    this.getProductByName(this.title[1]);
  }


  bat() {
    this.getProductByName(this.title[2]);
  }

  ball() {
    this.getProductByName(this.title[3]);
  }

  shuttlecock() {
    this.getProductByName(this.title[4]);
  }

  stumps() {
    this.getProductByName(this.title[5]);
  }

  badmintonRacket() {
    this.getProductByName(this.title[6]);
  }

  volleyball() {
    this.getProductByName(this.title[7]);
  }

  addOrder(name: any) {
    this.service.getProductList().subscribe(data => {
      this.dataSource = data;
      console.log(this.dataSource);
      for (let i = 0; i < this.dataSource.length; i++) {

        if (this.dataSource[i].name == name) {
          this.order.quantity=1;
          this.order.product = this.dataSource[i].name;
          this.order.price = this.dataSource[i].price * this.order.quantity;
          
          this.service.createOrder(this.order).subscribe(value => {
            console.log(value);
            this.orderD = value;
            this.OrderDetails(this.orderD.orderId);
          })
        }
      }
    })
  }
  OrderDetails(orderId: number) {
    this.router.navigate(['order/update', orderId]);
  }
}


