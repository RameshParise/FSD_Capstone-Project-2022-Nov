import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderService } from 'src/app/shared/order.service';
import { Order } from '../order';


@Component({
  selector: 'app-update-order',
  templateUrl: './update-order.component.html',
  styleUrls: ['./update-order.component.scss']
})
export class UpdateOrderComponent implements OnInit {
  orderId!: number;
  order: Order = new Order();
  products:any;

  constructor(private service: OrderService, private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.orderId = this.route.snapshot.params['orderId'];
    console.log(this.orderId);
    this.service.getOrder(this.orderId).subscribe(data => {
      this.order = data;
    })
    
  }

  onSubmit() {
    this.service.getProductByName(this.order.product).subscribe(value=>{
      this.products =value;
    })

    this.order.price=this.products.price*this.order.quantity;
    this.service.updateOrder(this.orderId, this.order).subscribe(data => {
      this.goToOrderList();
    }
    );
  }

  goToOrderList() {
    this.router.navigate(['order/list']);
  }
}
