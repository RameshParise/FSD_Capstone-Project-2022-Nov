package com.order;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.order.entity.Order;
import com.order.entity.Product;
import com.order.entity.User;
import com.order.repo.OrderRepo;
import com.order.repo.ProductRepo;
import com.order.repo.UserRepo;
import com.order.service.OrderService;
import com.order.service.ProductService;
import com.order.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
class OrderManagementSystemApplicationTests {

	@Autowired
	private OrderService orderService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserService userService;
	
	@MockBean
	private OrderRepo orderRepo;
	
	@MockBean
	private ProductRepo productRepo;
	
	@MockBean
    private UserRepo userRepo;
	
	@Test
	void contextLoads() {
	}

	//test cases for OrderService
	
	@Test
	@org.junit.jupiter.api.Order(3)
	public void getAllOrders()
	{
		when(this.orderRepo.findAll()).thenReturn(Stream.
				of(new Order(1L,"ball",100.0,1L,"7709952688","ganesh123@gmail.com","Nalwandi")).collect(Collectors.toList()));
		assertEquals(1,this.orderService.getOrders().size());
	}
	
//	@Test
//	@org.junit.jupiter.api.Order(2)
//	public void  getOrderById()
//	{
//		Order order=new Order(1L,"ball",100.0,1L,"7709952688","ganesh123@gmail.com","Nalwandi");
//		this.orderRepo.save(order);
//		this.orderService.getorder(1L);
//		verify(this.orderRepo,times(1)).findById(1L).get();
//	}
	
	@Test
	@org.junit.jupiter.api.Order(1)
	public void saveOrder()
	{
		Order order=new Order(1L,"ball",100.0,1L,"7709952688","ganesh123@gmail.com","Nalwandi");
		when(this.orderRepo.save(order)).thenReturn(order);
		assertEquals(order,this.orderService.saveOrder(order));
	}
	
	@Test
	@org.junit.jupiter.api.Order(4)
	public void deleteOrder()
	{
		Order order=new Order(1L,"ball",100.0,1L,"7709952688","ganesh123@gmail.com","Nalwandi");
	this.orderService.deleteOrder(1L);
		verify(this.orderRepo,times(1)).deleteById(1L);
	}
	
	// Test cases for Product Service
	@Test
	@org.junit.jupiter.api.Order(5)
	public void getProductsList()
	{
		when(this.productRepo.findAll()).thenReturn(Stream.
				of(new Product(1L,"ball",400.0,"2y","nice")).collect(Collectors.toList()));
		assertEquals(1,this.productService.getProducts().size());
	}
	
	@Test
	@org.junit.jupiter.api.Order(6)
	public void  getProductByNameTest()
	{
		Product p=new Product(1L,"ball",400.0,"2y","nice");
		this.productService.getProductByName("ball");
		verify(this.productRepo,times(1)).findByName("ball");
	}
	
	//Test cases for UserService
	
	@Test
	@org.junit.jupiter.api.Order(7)
	public void saveUserTest()
	{
		User user=new User(1L,"Ganesh","ganesh123@gmail.com","Ganesh@123");
		when(this.userRepo.save(user)).thenReturn(user);
		assertEquals(user,this.userService.saveUser(user));
	}
	
	@Test
	@org.junit.jupiter.api.Order(8)
	public void userLoginTest()
	{
		User user=new User(1L,"Ganesh","ganesh123@gmail.com","Ganesh@123");
		
		when(this.userRepo.save(user)).thenReturn(user);
		assertEquals(user,this.userService.saveUser(user));
	}
}
