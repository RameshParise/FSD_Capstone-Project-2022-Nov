package com.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.order.entity.Order;
import com.order.entity.Product;
import com.order.entity.User;
import com.order.service.OrderService;
import com.order.service.ProductService;
import com.order.service.UserService;

@RestController
@CrossOrigin("*")

public class OrderController {

	@Autowired
	private OrderService orderService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserService userService;
	
	
	@PostMapping("/signup")
	public User saveUser(@RequestBody User user) {
		return this.userService.saveUser(user);
	}
	
	@PostMapping("/users")
	public ResponseEntity<?> userLogin(@RequestBody User user)
	{
		User u= this.userService.getUserByUserName(user.getUsername());
		if(u.getPassword().equals(user.getPassword()))
		return ResponseEntity.ok(u);
		
		return (ResponseEntity<?>) ResponseEntity.internalServerError();
		
	}
	
	@GetMapping("/products/{pname}")
	public Product getProductByName(@PathVariable ("pname") String name)
	{
		return this.productService.getProductByName(name);	
	}
	
	@GetMapping("/products")
	public List<Product>getProducts()
	{
		return this.productService.getProducts();
		
	}
	
	@GetMapping("/orders")
	public List<Order>getAllOrders()
	{
		return this.orderService.getOrders();
	}
	
	@GetMapping("/orders/{id}")
	public Order getOrder(@PathVariable("id") Long orderId)
	{
		return this.orderService.getorder(orderId);
	}
	
	@PostMapping("/orders")
	public Order saveOrder(@RequestBody Order order)
	{
		return this.orderService.saveOrder(order);	
	}
	
	@PutMapping("/orders/{id}")
	public Order updateOrder(@RequestBody Order order)
	{
		return this.orderService.updateOrder(order);
		
	}
	
	@DeleteMapping("/orders/{id}")
	public String deleteOrder(@PathVariable ("id") Long orderId ) {
		this.orderService.deleteOrder(orderId);
		return "Order Cancel";
	}
}
