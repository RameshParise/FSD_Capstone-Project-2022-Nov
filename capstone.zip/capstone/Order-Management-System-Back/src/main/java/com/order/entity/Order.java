package com.order.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Order_Details")
public class Order {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Order_Id")
	private Long orderId;
	
	@Column(name="Product_Names")
	private String  product;
	
	@Column(name="Order_Price")
	private Double price;
	
	@Column(name="Order_Quantity")
	private Long quantity
;
	
	@Column(name="Phone_number")
	private String phone;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Delevery_address")
	private String address;

	public Order() {
		super();
	}

	public Order(Long orderId, String product, Double price, Long quantity, String phone, String email,
			String address) {
		super();
		this.orderId = orderId;
		this.product = product;
		this.price = price;
		this.quantity = quantity;
		this.phone = phone;
		this.email = email;
		this.address = address;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}	
}
