package com.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.entity.Order;
import com.order.repo.OrderRepo;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepo orderRepo;
	
	@Override
	public Order getorder(Long id) {
		// TODO Auto-generated method stub
		return this.orderRepo.findById(id).get();
	}

	@Override
	public void deleteOrder(Long id) {
		// TODO Auto-generated method stub
		this.orderRepo.deleteById(id);
		
	}

	@Override
	public Order updateOrder(Order order) {
		// TODO Auto-generated method stub
		return this.orderRepo.saveAndFlush(order);
	}

	@Override
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		System.out.println(this.orderRepo.findAll());
		return this.orderRepo.findAll();
		
	}

	@Override
	public Order saveOrder(Order order) {
		// TODO Auto-generated methtod stub
		return this.orderRepo.save(order);
	}

}
