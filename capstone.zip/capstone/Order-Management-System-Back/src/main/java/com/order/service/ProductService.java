package com.order.service;

import java.util.List;

import com.order.entity.Product;

public interface ProductService {

	public Product saveProduct(Product product);
	
	public Product getProductByName(String name);
	
	public void deleteProduct(Long id);
	
	public List<Product> getProducts();
	
	public Product updateProduct(Product product);
}
