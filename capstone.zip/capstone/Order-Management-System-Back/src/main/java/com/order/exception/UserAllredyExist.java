package com.order.exception;

public class UserAllredyExist extends Exception {

	private static final long serialVersionUID = 1L;

	public  UserAllredyExist(String message)
	{
		super(message);
	}
}
