package com.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.entity.Product;
import com.order.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepo productRepo;
	
	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return this.productRepo.save(product);
	}

	@Override
	public Product getProductByName(String name) {
		// TODO Auto-generated method stub
		return (Product) this.productRepo.findByName(name);
	}

	@Override
	public void deleteProduct(Long id) {
		this.productRepo.deleteById(id);	
	}

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return this.productRepo.findAll();
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return this.productRepo.saveAndFlush(product);
	}

	
}
