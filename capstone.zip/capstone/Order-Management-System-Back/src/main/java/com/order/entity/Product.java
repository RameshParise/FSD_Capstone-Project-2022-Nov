package com.order.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product_Details")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Product_Id")
	private Long productId;
	
	@Column(name="Product_name")
	private String name;
	
	@Column(name="Product_price")
	private Double price;
	
	@Column(name="Product_warranty")
	private String warranty;
	
	@Column(name="Product_description")
	private String description;

	public Product() {
		super();
	}

	public Product(Long productId, String name, Double price, String warranty, String description) {
		super();
		this.productId = productId;
		this.name = name;
		this.price = price;
		this.warranty = warranty;
		this.description = description;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getWarranty() {
		return warranty;
	}

	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
