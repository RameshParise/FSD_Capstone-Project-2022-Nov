package com.order.service;

import java.util.List;

import com.order.entity.Order;

public interface OrderService {

	public Order saveOrder(Order order);
	
	public Order getorder(Long id);
	
	public void deleteOrder(Long id);
	
	public List<Order> getOrders();
	
	public Order updateOrder(Order order);
}
