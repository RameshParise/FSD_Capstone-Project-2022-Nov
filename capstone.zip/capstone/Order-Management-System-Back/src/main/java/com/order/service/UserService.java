package com.order.service;

import com.order.entity.User;

public interface UserService {
	
	public User saveUser(User user);
	
	public User getUserByUserName(String name);
}
